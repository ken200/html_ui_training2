﻿/// <reference path="../Scripts/typings/jquery/jquery.d.ts" />
var bempage;
(function (bempage) {
    var PageData = (function () {
        function PageData() {
        }
        return PageData;
    })();
    bempage.PageData = PageData;

    var PageButton = (function () {
        function PageButton(no) {
            this.no = no;
        }
        PageButton.prototype.draw = function (parent) {
        };
        return PageButton;
    })();

    var JumpButton = (function () {
        function JumpButton(caption, action) {
            this.caption = caption;
            this.action = action;
        }
        JumpButton.prototype.draw = function (parent) {
            this.action(parent);
        };
        return JumpButton;
    })();

    var Pager = (function () {
        function Pager() {
            this.amountPerPage = 10;
        }
        Pager.prototype.calcPagerPage = function () {
            return 0;
        };

        Pager.prototype.load = function (data) {
            this.data = data;
        };
        return Pager;
    })();
    bempage.Pager = Pager;
})(bempage || (bempage = {}));
//# sourceMappingURL=bem_page.js.map
