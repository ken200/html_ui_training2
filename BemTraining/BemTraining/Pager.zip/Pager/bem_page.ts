﻿/// <reference path="../Scripts/typings/jquery/jquery.d.ts" />
module bempage {

    export class PageData {
        constructor() { }
    }

    interface ButtonView {
        draw: (parent : JQuery) => void;
    }

    class PageButton implements ButtonView  {
        constructor(public no: number) { }
        draw(parent: JQuery) {
        }
    }

    class JumpButton implements ButtonView {
        private action: (parent: JQuery) => void;
        constructor(public caption: string, action: (parent:JQuery) => void) {
            this.action = action;
        }
        draw(parent: JQuery) {
            this.action(parent);
        }
    }

    export class Pager{

        private amountPerPage: number;

        private data: Array<PageData>;
        private buttons: Array<ButtonView>;

        constructor() {
            this.amountPerPage = 10;
        }

        private calcPagerPage(): number {

            return 0;

        }

        load(data: Array<PageData>) {
            this.data = data;



        }

    }

}